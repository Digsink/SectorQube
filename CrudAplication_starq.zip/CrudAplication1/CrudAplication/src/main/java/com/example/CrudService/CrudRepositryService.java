package com.example.CrudService;

import org.springframework.beans.factory.annotation.Autowired;

public class CrudRepositryService {
	@Autowired
	CrudRepositry crudRepositry;

}
