package com.example.CrudService;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.CrudModel.Employee;

public interface CrudRepositry extends JpaRepository<Employee, String>{

}
