package com.example.CrudService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.CrudModel.Employee;

@Service
public class CrudService {
	
@Autowired
CrudRepositryService crudRepositryService;
@Autowired
CrudRepositry crudRepositry;

public String fetchEmployee(String id)
{
	return crudRepositry.findById(id).toString();
}

public String updateEmployee(Employee employee)
{
	
	return crudRepositry.save(employee) .toString();
}
public String deleteEmployee(String id)
{
	crudRepositry.deleteById(id);
	return "Sucessfully deleted Employee with id"+id;
	
}
public String insertEmployee(Employee employeeToInsert)
{
	return crudRepositry.save(employeeToInsert) .toString();
}
}
