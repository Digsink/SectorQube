package com.example.CrudAplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudAplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudAplicationApplication.class, args);
	}

}
