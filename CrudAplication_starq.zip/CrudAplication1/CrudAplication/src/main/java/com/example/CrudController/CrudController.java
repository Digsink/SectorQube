package com.example.CrudController;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.CrudModel.Employee;
import com.example.CrudService.CrudService;

@Controller
@RequestMapping("/service")
public class CrudController {
	@Autowired
	CrudService crudService;
	@GetMapping("/fetch")
	public String getEmloyee(@RequestParam String id)
	
	{
		
		return crudService.fetchEmployee(id);
	}
	
	@PostMapping("/insert")
	public String insertEmployee(@RequestParam Employee e)
	{
		return crudService.insertEmployee(e);
	}
	
	@GetMapping("/delete/{pathVariable}")
	public String deleteEmployee(@PathParam("pathVariable") String id)
	{
		return crudService.deleteEmployee(id);
		
	}
	@PostMapping("/update")
	public String updateEmployee(@RequestParam Employee e)
	{
	return crudService.updateEmployee(e);	
	}

}
